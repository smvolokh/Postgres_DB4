create procedure install_dblink()
    language plpgsql
as
$$
begin

	create extension dblink;

end

$$;

alter procedure install_dblink() owner to postgres;

