create function output_db()
    returns TABLE(id name)
    language plpgsql
as
$$
begin

	return query (select datname from pg_database);

end;

$$;

alter function output_db() owner to postgres;

