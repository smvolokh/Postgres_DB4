create procedure create_db(text, text)
    language plpgsql
as
$$
begin

	perform dblink_exec('dbname='||current_database()||' user='||current_user||' password='|| $2,

						'create database '|| $1 || ' with owner= '|| current_user);

end

$$;

alter procedure create_db(text, text) owner to postgres;

